package com.sebi.lifeos.lifeosapp.data

data class AppWithCategoryTotalRow(
    val packageName: String,
    val label: String,
    val categoryId: Long,
    val totalMs: Long
)
