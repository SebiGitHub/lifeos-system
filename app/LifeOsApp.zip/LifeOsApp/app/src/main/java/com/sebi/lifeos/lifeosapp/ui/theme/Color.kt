package com.sebi.lifeos.lifeosapp.ui.theme

import androidx.compose.ui.graphics.Color

// Light
val Primary = Color(0xFF9555D7)
val Secondary = Color(0xFF81C4E4)
val Tertiary = Color(0xFFF0C030)

val Background = Color(0xFFFEFEFE)
val Surface = Color(0xFFF7F5FF)

val OnPrimary = Color(0xFFFFFFFF)
val OnSecondary = Color(0xFF0B1B22)
val OnTertiary = Color(0xFF231A00)
val OnBackground = Color(0xFF1A1A1A)
val OnSurface = Color(0xFF1A1A1A)

// Dark (derivados “a ojo” para que se vea bien)
val PrimaryDark = Color(0xFFB78EF1)
val SecondaryDark = Color(0xFF7CC9EA)
val TertiaryDark = Color(0xFFF3D06A)

val BackgroundDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1D1826)

val OnPrimaryDark = Color(0xFF1A0F26)
val OnSecondaryDark = Color(0xFF061318)
val OnTertiaryDark = Color(0xFF1A1200)
val OnBackgroundDark = Color(0xFFF2F2F2)
val OnSurfaceDark = Color(0xFFF2F2F2)

// ✅ Extras para UI (tabs)
val Lilac = Color(0xFFB78EF1)      // Catálogo
val GreyTab = Color(0xFF9AA0A6)    // Ajustes

val LilacDark = Color(0xFFD8C2FF)
val GreyTabDark = Color(0xFFB9BDC2)
