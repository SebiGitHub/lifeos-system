package com.sebi.lifeos.lifeosapp.domain

const val MIN_APP_MS: Long = 5L * 60L * 1000L
const val DEFAULT_TOP_LIMIT: Int = 10
