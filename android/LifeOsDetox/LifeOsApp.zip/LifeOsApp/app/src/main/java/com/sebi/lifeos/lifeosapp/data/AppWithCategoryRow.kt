package com.sebi.lifeos.lifeosapp.data

data class AppWithCategoryRow(
    val packageName: String,
    val label: String,
    val categoryId: Long
)
