package com.sebi.lifeos.lifeosapp


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sebi.lifeos.lifeosapp.data.LifeOsDb
import com.sebi.lifeos.lifeosapp.repo.UsageRepository
import com.sebi.lifeos.lifeosapp.ui.AppCatalogScreen
import com.sebi.lifeos.lifeosapp.usage.UsageAccess
import com.sebi.lifeos.lifeosapp.worker.DailyUsageScheduler
import kotlinx.coroutines.launch
import java.time.ZoneId
import java.time.ZonedDateTime
import com.sebi.lifeos.lifeosapp.ui.YearScreen
import com.sebi.lifeos.lifeosapp.ui.YearViewModel
import com.sebi.lifeos.lifeosapp.ui.theme.theme.LifeOsAppTheme


private const val TAB_HOY = "HOY"
private const val TAB_ANO = "ANO"
private const val TAB_CATALOGO = "CATALOGO"


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val db = LifeOsDb.get(this)
        val repo = UsageRepository(this, db)

        setContent {
            LifeOsAppTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppRoot(repo)
                }
            }
        }
    }
}

@Composable
private fun AppRoot(repo: UsageRepository) {
    var tab by remember { mutableStateOf(TAB_HOY) }
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val yearVm = remember(repo) { YearViewModel(ctx, repo) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TabButton(text = "Hoy", selected = tab == TAB_HOY) { tab = TAB_HOY }
            TabButton(text = "Año", selected = tab == TAB_ANO) { tab = TAB_ANO }
            TabButton(text = "Catálogo", selected = tab == TAB_CATALOGO) { tab = TAB_CATALOGO }
        }

        Spacer(Modifier.height(12.dp))

        // Importante: el contenido ocupa el espacio disponible SIN tapar la barra de botones
        Box(Modifier.weight(1f)) {
            when (tab) {
                TAB_HOY -> DetoxScreen(repo)
                TAB_ANO -> YearScreen(yearVm)
                TAB_CATALOGO -> AppCatalogScreen(repo)
            }
        }
    }
}

@Composable
private fun TabButton(
    text: String,
    selected: Boolean,
    onClick: () -> Unit
) {
    if (selected) {
        Button(onClick = onClick) { Text(text) }
    } else {
        FilledTonalButton(onClick = onClick) { Text(text) }
    }
}

@Composable
private fun DetoxScreen(repo: UsageRepository) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val scope = rememberCoroutineScope()

    var hasAccess by remember { mutableStateOf(UsageAccess.hasUsageAccess(ctx)) }
    var dayKey by remember { mutableStateOf(currentDayKey()) }
    var topApps by remember { mutableStateOf(listOf<com.sebi.lifeos.lifeosapp.data.AppUsageAgg>()) }

    fun refreshTop() {
        scope.launch {
            topApps = repo.topAppsToday(dayKey)
        }
    }

    LaunchedEffect(Unit) {
        refreshTop()
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("LifeOS Detox (Android)", style = MaterialTheme.typography.titleLarge)

        Card {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Acceso a uso: " + if (hasAccess) "✅ Concedido" else "⛔ No concedido")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        UsageAccess.openUsageAccessSettings(ctx)
                    }) { Text("Conceder permiso") }

                    Button(onClick = {
                        hasAccess = UsageAccess.hasUsageAccess(ctx)
                    }) { Text("Revisar") }
                }
            }
        }

        Card {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Día (corte 23:30): $dayKey")
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = {
                        DailyUsageScheduler.runNow(ctx)
                    }) { Text("Sync ahora") }

                    Button(onClick = {
                        hasAccess = UsageAccess.hasUsageAccess(ctx)
                        dayKey = currentDayKey()
                        refreshTop()
                    }) { Text("Actualizar lista") }
                }
            }
        }

        Text("Top apps hoy", style = MaterialTheme.typography.titleMedium)
        if (topApps.isEmpty()) {
            Text("Sin datos todavía. Concede permiso y pulsa 'Sync ahora'.")
        } else {
            topApps.forEach {
                val minutes = (it.totalMs / 60000.0)
                Text("• ${it.label}: ${"%.1f".format(minutes)} min")
            }
        }
    }
}

private fun currentDayKey(): String {
    val zone = ZoneId.of("Europe/Madrid")
    val now = ZonedDateTime.now(zone)
    val cutoffToday = now.toLocalDate().atTime(23, 30).atZone(zone)
    val end = if (now.isAfter(cutoffToday)) cutoffToday else cutoffToday.minusDays(1)
    return end.toLocalDate().toString()
}
