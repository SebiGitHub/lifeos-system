package com.sebi.lifeos.lifeosapp.worker

import android.content.Context
import androidx.work.*
import java.time.Duration
import java.time.ZoneId
import java.time.ZonedDateTime
import java.util.concurrent.TimeUnit

object DailyUsageScheduler {
    private const val WORK_NAME = "daily_usage_capture"

    fun scheduleNext(context: Context) {
        val zone = ZoneId.of("Europe/Madrid")
        val now = ZonedDateTime.now(zone)

        // Próxima ejecución: 00:10
        var next = now.withHour(0).withMinute(10).withSecond(0).withNano(0)
        if (!now.isBefore(next)) next = next.plusDays(1)

        val delayMs = Duration.between(now, next).toMillis().coerceAtLeast(0)

        val req = OneTimeWorkRequestBuilder<DailyUsageWorker>()
            .setInitialDelay(delayMs, TimeUnit.MILLISECONDS)
            .addTag(WORK_NAME)
            .build()

        WorkManager.getInstance(context)
            .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, req)
    }

    fun runNow(context: Context) {
        val req = OneTimeWorkRequestBuilder<DailyUsageWorker>()
            .addTag(WORK_NAME)
            .build()
        WorkManager.getInstance(context).enqueue(req)
    }
}
