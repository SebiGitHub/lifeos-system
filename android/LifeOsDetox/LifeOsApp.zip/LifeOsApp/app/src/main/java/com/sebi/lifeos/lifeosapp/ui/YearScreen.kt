package com.sebi.lifeos.lifeosapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToLong

@Composable
fun YearScreen(vm: YearViewModel) {
    val state by vm.state.collectAsState()
    val snack = remember { SnackbarHostState() }

    LaunchedEffect(state.snackbar) {
        val msg = state.snackbar ?: return@LaunchedEffect
        snack.showSnackbar(msg)
        vm.consumeSnackbar()
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snack) }
    ) { padding ->
        Column(
            Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Card {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Resumen anual", style = MaterialTheme.typography.titleMedium)

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = state.year,
                            onValueChange = { vm.setYear(it.filter(Char::isDigit).take(4)) },
                            label = { Text("Año") },
                            modifier = Modifier.weight(1f)
                        )
                        Button(onClick = { vm.loadYear() }) { Text("Cargar") }
                    }

                    Button(
                        onClick = { vm.exportCsvToDownloads() },
                        enabled = !state.exporting
                    ) {
                        Text(if (state.exporting) "Exportando..." else "Exportar CSV")
                    }
                }
            }

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item { Text("Top apps del año", style = MaterialTheme.typography.titleMedium) }
                items(state.apps.take(50), key = { it.packageName }) { r ->
                    val minutes = (r.totalMs / 60000.0).roundToLong()
                    Text("• ${r.label}: ${formatMin(minutes)}")
                }

                item { Spacer(Modifier.height(8.dp)) }

                item { Text("Categorías del año", style = MaterialTheme.typography.titleMedium) }
                items(state.categories, key = { it.category }) { r ->
                    val minutes = (r.totalMs / 60000.0).roundToLong()
                    Text("• ${r.category}: ${formatMin(minutes)}")
                }
            }
        }
    }
}

private fun formatMin(min: Long): String {
    val h = min / 60
    val m = min % 60
    return if (h > 0) "${h}h ${m}m" else "${m}m"
}
