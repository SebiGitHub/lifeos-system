package com.sebi.lifeos.lifeosapp.usage

import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager

object AppMetaMapper {

    fun resolveLabel(pm: PackageManager, pkg: String): String =
        try {
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
        } catch (_: Throwable) {
            pkg
        }

    fun resolveCategory(pm: PackageManager, pkg: String): String =
        try {
            val ai = pm.getApplicationInfo(pkg, 0)
            when (ai.category) {
                ApplicationInfo.CATEGORY_GAME -> "Juegos"
                ApplicationInfo.CATEGORY_VIDEO -> "Video"
                ApplicationInfo.CATEGORY_AUDIO -> "Música"
                ApplicationInfo.CATEGORY_SOCIAL -> "Social"
                ApplicationInfo.CATEGORY_PRODUCTIVITY -> "Productividad"
                ApplicationInfo.CATEGORY_NEWS -> "Noticias"
                ApplicationInfo.CATEGORY_MAPS -> "Mapas"
                else -> "Otros"
            }
        } catch (_: Throwable) {
            "Otros"
        }
}
