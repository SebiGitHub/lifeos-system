package com.sebi.lifeos.lifeosapp.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sebi.lifeos.lifeosapp.data.AppWithCategoryRow
import com.sebi.lifeos.lifeosapp.data.CategoryEntity
import com.sebi.lifeos.lifeosapp.repo.UsageRepository
import kotlinx.coroutines.launch
import androidx.compose.material3.ExperimentalMaterial3Api

@Composable
fun AppCatalogScreen(repo: UsageRepository) {
    val scope = rememberCoroutineScope()

    var apps by remember { mutableStateOf(emptyList<AppWithCategoryRow>()) }
    var cats by remember { mutableStateOf(emptyList<CategoryEntity>()) }
    var loading by remember { mutableStateOf(true) }

    suspend fun load() {
        loading = true
        cats = repo.categories()
        apps = repo.appsWithCategory()
        loading = false
    }

    LaunchedEffect(Unit) { load() }

    Column(
        Modifier.fillMaxSize().padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Catálogo de apps", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.weight(1f))
            FilledTonalButton(onClick = { scope.launch { load() } }) { Text("Recargar") }
        }

        if (loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
            return@Column
        }

        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(apps, key = { it.packageName }) { app ->
                Card {
                    Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(app.label)
                        Text(app.packageName, style = MaterialTheme.typography.bodySmall)

                        CategoryDropdown(
                            categories = cats,
                            selectedId = app.categoryId,
                            onSelect = { newId ->
                                scope.launch {
                                    repo.setAppCategory(app.packageName, newId)
                                    apps = repo.appsWithCategory() // recarga
                                }
                            }
                        )
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun CategoryDropdown(
    categories: List<CategoryEntity>,
    selectedId: Long,
    onSelect: (Long) -> Unit
) {
    var expanded by remember { mutableStateOf(false) }
    val selectedName = categories.firstOrNull { it.id == selectedId }?.name ?: "?"

    ExposedDropdownMenuBox(expanded = expanded, onExpandedChange = { expanded = !expanded }) {
        OutlinedTextField(
            value = selectedName,
            onValueChange = {},
            readOnly = true,
            modifier = Modifier.menuAnchor().fillMaxWidth(),
            label = { Text("Categoría") }
        )
        ExposedDropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            categories.forEach { c ->
                DropdownMenuItem(
                    text = { Text(c.name) },
                    onClick = {
                        expanded = false
                        onSelect(c.id)
                    }
                )
            }
        }
    }
}
