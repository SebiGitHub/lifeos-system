package com.sebi.lifeos.lifeosapp.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

data class AppUsageAgg(
    val packageName: String,
    val label: String,
    val totalMs: Long
)

data class CategoryUsageAgg(
    val categoryId: Long,
    val categoryName: String,
    val totalMs: Long
)

@Dao
interface CategoryDao {
    @Query("SELECT * FROM categories ORDER BY name ASC")
    suspend fun getAll(): List<CategoryEntity>

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertAll(items: List<CategoryEntity>)

    @Query("SELECT id FROM categories WHERE name = :name LIMIT 1")
    suspend fun getIdByName(name: String): Long?
}

@Dao
interface AppDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(app: AppEntity)

    @Query("SELECT * FROM apps ORDER BY label ASC")
    suspend fun getAll(): List<AppEntity>

    @Query("SELECT packageName, label, categoryId FROM apps ORDER BY label COLLATE NOCASE")
    suspend fun appsWithCategory(): List<AppWithCategoryRow>

    @Query("UPDATE apps SET categoryId = :categoryId WHERE packageName = :packageName")
    suspend fun setAppCategory(packageName: String, categoryId: Long)
}

@Dao
interface UsageDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<UsageDayEntity>)

    @Transaction
    @Query("""
        SELECT a.packageName as packageName, a.label as label, SUM(u.foregroundMs) as totalMs
        FROM usage_day u
        JOIN apps a ON a.packageName = u.packageName
        WHERE u.dayKey = :dayKey
        GROUP BY a.packageName, a.label
        ORDER BY totalMs DESC
        LIMIT :limit
    """)
    suspend fun topAppsForDay(dayKey: String, limit: Int = 10): List<AppUsageAgg>

    @Transaction
    @Query("""
        SELECT a.packageName as packageName, a.label as label, SUM(u.foregroundMs) as totalMs
        FROM usage_day u
        JOIN apps a ON a.packageName = u.packageName
        WHERE substr(u.dayKey, 1, 4) = :year
        GROUP BY a.packageName, a.label
        ORDER BY totalMs DESC
        LIMIT :limit
    """)
    suspend fun topAppsForYear(year: String, limit: Int = 50): List<AppUsageAgg>

    @Transaction
    @Query("""
        SELECT c.id as categoryId, c.name as categoryName, SUM(u.foregroundMs) as totalMs
        FROM usage_day u
        JOIN apps a ON a.packageName = u.packageName
        JOIN categories c ON c.id = a.categoryId
        WHERE substr(u.dayKey, 1, 4) = :year
        GROUP BY c.id, c.name
        ORDER BY totalMs DESC
    """)
    suspend fun totalsByCategoryForYear(year: String): List<CategoryUsageAgg>
}


@Dao
interface AppCatalogDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<AppCatalogEntity>)

    @Query("SELECT * FROM app_catalog WHERE packageName = :pkg LIMIT 1")
    suspend fun get(pkg: String): AppCatalogEntity?
}

data class AnnualAppTotal(
    val packageName: String,
    val totalMinutes: Double
)

data class AnnualCategoryTotal(
    val category: String,
    val totalMinutes: Double
)

@Dao
interface UsageEntryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAll(items: List<UsageEntryEntity>)

    @Query("""
        SELECT packageName, SUM(minutes) AS totalMinutes
        FROM usage_entries
        WHERE dayKey LIKE :yearPrefix
        GROUP BY packageName
        ORDER BY totalMinutes DESC
    """)
    suspend fun annualByApp(yearPrefix: String): List<AnnualAppTotal>

    @Query("""
        SELECT COALESCE(ac.userCategory, ac.category, 'Otros') AS category,
               SUM(ue.minutes) AS totalMinutes
        FROM usage_entries ue
        LEFT JOIN app_catalog ac ON ac.packageName = ue.packageName
        WHERE ue.dayKey LIKE :yearPrefix
        GROUP BY category
        ORDER BY totalMinutes DESC
    """)
    suspend fun annualByCategory(yearPrefix: String): List<AnnualCategoryTotal>
}

