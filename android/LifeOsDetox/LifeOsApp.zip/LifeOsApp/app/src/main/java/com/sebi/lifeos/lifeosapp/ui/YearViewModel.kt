package com.sebi.lifeos.lifeosapp.ui

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sebi.lifeos.lifeosapp.data.YearAppRow
import com.sebi.lifeos.lifeosapp.data.YearCategoryRow
import com.sebi.lifeos.lifeosapp.repo.UsageRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.io.File
import java.io.FileOutputStream
import java.time.LocalDate
import java.util.Locale

data class YearState(
    val year: String = LocalDate.now().year.toString(),
    val apps: List<YearAppRow> = emptyList(),
    val categories: List<YearCategoryRow> = emptyList(),
    val exporting: Boolean = false,
    val snackbar: String? = null
)

class YearViewModel(
    private val context: Context,
    private val repo: UsageRepository
) : ViewModel() {

    private val _state = MutableStateFlow(YearState())
    val state: StateFlow<YearState> = _state

    fun setYear(y: String) {
        _state.update { it.copy(year = y) }
    }

    fun consumeSnackbar() {
        _state.update { it.copy(snackbar = null) }
    }

    fun loadYear() {
        val y = _state.value.year
        viewModelScope.launch {
            try {
                val appsAgg = repo.topAppsYear(y)
                val catsAgg = repo.totalsByCategoryYear(y)
                val categoryNameById = repo.categories().associate { it.id to it.name }

                val apps = appsAgg.map { YearAppRow(it.packageName, it.label, it.totalMs) }
                val cats = catsAgg.map {
                    val name = categoryNameById[it.categoryId] ?: "Sin categoría"
                    YearCategoryRow(name, it.totalMs)
                }

                _state.update { it.copy(apps = apps, categories = cats) }
            } catch (e: Exception) {
                _state.update { it.copy(snackbar = "Error al cargar: ${e.message ?: "desconocido"}") }
            }
        }
    }

    fun exportCsvToDownloads() {
        viewModelScope.launch {
            val y = _state.value.year
            _state.update { it.copy(exporting = true, snackbar = null) }

            try {
                val appsAgg = repo.topAppsYear(y)
                val catsAgg = repo.totalsByCategoryYear(y)
                val categoryNameById = repo.categories().associate { it.id to it.name }

                val apps = appsAgg.map { YearAppRow(it.packageName, it.label, it.totalMs) }
                val cats = catsAgg.map {
                    val name = categoryNameById[it.categoryId] ?: "Sin categoría"
                    YearCategoryRow(name, it.totalMs)
                }

                val appsCsv = buildAppsCsv(apps)
                val catsCsv = buildCatsCsv(cats)

                val appsName = "year_apps_$y.csv"
                val catsName = "year_categories_$y.csv"

                saveTextToDownloads(context, appsName, appsCsv)
                saveTextToDownloads(context, catsName, catsCsv)

                _state.update {
                    it.copy(
                        exporting = false,
                        apps = apps,
                        categories = cats,
                        snackbar = "CSV guardado en Descargas: $appsName y $catsName"
                    )
                }
            } catch (e: Exception) {
                _state.update {
                    it.copy(
                        exporting = false,
                        snackbar = "Error exportando CSV: ${e.message ?: "desconocido"}"
                    )
                }
            }
        }
    }

    private fun buildAppsCsv(rows: List<YearAppRow>): String {
        val sb = StringBuilder()
        sb.appendLine("package,label,total_minutes,total_hours")
        for (r in rows) {
            val minutes = r.totalMs / 60000.0
            val hours = minutes / 60.0
            sb.appendLine("${csv(r.packageName)},${csv(r.label)},${fmt(minutes)},${fmt(hours)}")
        }
        return sb.toString()
    }

    private fun buildCatsCsv(rows: List<YearCategoryRow>): String {
        val sb = StringBuilder()
        sb.appendLine("category,total_minutes,total_hours")
        for (r in rows) {
            val minutes = r.totalMs / 60000.0
            val hours = minutes / 60.0
            sb.appendLine("${csv(r.category)},${fmt(minutes)},${fmt(hours)}")
        }
        return sb.toString()
    }

    private fun csv(v: String): String {
        val needsQuotes = v.contains(",") || v.contains("\"") || v.contains("\n")
        val escaped = v.replace("\"", "\"\"")
        return if (needsQuotes) "\"$escaped\"" else escaped
    }

    private fun fmt(v: Double): String = String.format(Locale.US, "%.2f", v)
}

private fun saveTextToDownloads(context: Context, fileName: String, content: String) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "text/csv")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        }
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return
        resolver.openOutputStream(uri)?.use { it.write(content.toByteArray()) }
    } else {
        val downloads = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!downloads.exists()) downloads.mkdirs()
        val file = File(downloads, fileName)
        FileOutputStream(file).use { it.write(content.toByteArray()) }
    }
}
