package com.sebi.lifeos.lifeosapp.repo

import android.content.Context
import com.sebi.lifeos.lifeosapp.data.*
import com.sebi.lifeos.lifeosapp.usage.AppMetaMapper
import com.sebi.lifeos.lifeosapp.usage.UsageCollector

class UsageRepository(private val context: Context, private val db: LifeOsDb) {

    private val categoryDao = db.categoryDao()
    private val appDao = db.appDao()
    private val usageDao = db.usageDao()

    private val defaultCategories = listOf(
        "Sin categoría", "Social", "Video", "Juegos", "Música", "Estudio", "Productivo", "Otros"
    )

    suspend fun ensureCategories() {
        val existing = categoryDao.getAll()
        if (existing.isNotEmpty()) return
        categoryDao.insertAll(defaultCategories.map { CategoryEntity(name = it) })
    }

    private suspend fun ensureCategoryId(name: String, fallbackId: Long): Long {
        val existing = categoryDao.getIdByName(name)
        if (existing != null) return existing
        categoryDao.insertAll(listOf(CategoryEntity(name = name)))
        return categoryDao.getIdByName(name) ?: fallbackId
    }

    suspend fun collectAndStoreDay(dayKey: String, startMs: Long, endMs: Long) {
        ensureCategories()

        val uncategorizedId = categoryDao.getIdByName("Sin categoría")
            ?: error("No existe categoría 'Sin categoría'")

        val pm = context.packageManager
        val statsMap = UsageCollector.aggregateUsage(context, startMs, endMs)

        val existingApps = appDao.getAll().associateBy { it.packageName }
        val usageRows = mutableListOf<UsageDayEntity>()

        for ((packageName, stats) in statsMap) {
            val fg = stats.totalTimeInForeground
            if (fg <= 0) continue

            val label = AppMetaMapper.resolveLabel(pm, packageName)
            val categoryName = AppMetaMapper.resolveCategory(pm, packageName)
            val mappedCategoryId = ensureCategoryId(categoryName, uncategorizedId)

            val prev = existingApps[packageName]
            val finalCategoryId =
                if (prev != null && prev.categoryId != uncategorizedId) prev.categoryId
                else mappedCategoryId

            appDao.upsert(AppEntity(packageName = packageName, label = label, categoryId = finalCategoryId))

            usageRows.add(UsageDayEntity(dayKey = dayKey, packageName = packageName, foregroundMs = fg))
        }

        usageDao.upsertAll(usageRows)
    }

    suspend fun topAppsToday(dayKey: String) = usageDao.topAppsForDay(dayKey, 10)
    suspend fun topAppsYear(year: String) = usageDao.topAppsForYear(year, 50)
    suspend fun totalsByCategoryYear(year: String) = usageDao.totalsByCategoryForYear(year)

    suspend fun categories() = categoryDao.getAll()
    suspend fun appsWithCategory() = appDao.appsWithCategory()
    suspend fun setAppCategory(packageName: String, categoryId: Long) = appDao.setAppCategory(packageName, categoryId)
}
