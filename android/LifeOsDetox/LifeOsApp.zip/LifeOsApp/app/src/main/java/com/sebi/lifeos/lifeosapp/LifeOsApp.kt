package com.sebi.lifeos.lifeosapp

import android.app.Application
import androidx.work.WorkManager
import com.sebi.lifeos.lifeosapp.worker.DailyUsageScheduler

class LifeOsApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Programa la captura diaria (se reprograma sola)
        DailyUsageScheduler.scheduleNext(this)
    }
}
