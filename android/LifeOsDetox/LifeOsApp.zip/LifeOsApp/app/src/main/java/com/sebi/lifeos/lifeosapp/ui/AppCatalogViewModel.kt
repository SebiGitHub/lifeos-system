package com.sebi.lifeos.lifeosapp.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sebi.lifeos.lifeosapp.data.AppWithCategoryRow
import com.sebi.lifeos.lifeosapp.data.CategoryEntity
import com.sebi.lifeos.lifeosapp.repo.UsageRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AppCatalogState(
    val loading: Boolean = false,
    val apps: List<AppWithCategoryRow> = emptyList(),
    val categories: List<CategoryEntity> = emptyList()
)

class AppCatalogViewModel(private val repo: UsageRepository) : ViewModel() {
    private val _state = MutableStateFlow(AppCatalogState())
    val state: StateFlow<AppCatalogState> = _state

    fun load() = viewModelScope.launch {
        _state.update { it.copy(loading = true) }
        val cats = repo.categories()
        val apps = repo.appsWithCategory()
        _state.update { it.copy(loading = false, categories = cats, apps = apps) }
    }

    fun setCategory(packageName: String, categoryId: Long) = viewModelScope.launch {
        repo.setAppCategory(packageName, categoryId)
        // refresca lista
        val apps = repo.appsWithCategory()
        _state.update { it.copy(apps = apps) }
    }
}
